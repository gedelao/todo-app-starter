const todoItems = [
  {
    id: 1,
    title: "Learn HTML",
    completed: true
  },
  {
    id: 2,
    title: "Learn CSS",
    completed: true
  },
  {
    id: 3,
    title: "Learn JS",
    completed: true
  },
  {
    id: 4,
    title: "Learn React",
    completed: false
  },
  {
    id: 5,
    title: "Learn Node",
    completed: false
  },
  {
    id: 6,
    title: "Learn Express",
    completed: false
  },
];
